import logging

logging.warning("Hello")
logging.error("Still here...")
logging.warning("Goodbye")